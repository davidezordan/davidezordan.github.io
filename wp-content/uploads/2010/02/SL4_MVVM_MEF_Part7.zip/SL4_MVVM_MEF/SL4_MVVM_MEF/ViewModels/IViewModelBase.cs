﻿using System.ComponentModel;
using System;

namespace SL4_MVVM_MEF.MEFModule.ViewModels
{
    /// <summary>
    /// Base ViewModel interface
    /// </summary>
    public interface IViewModelBase : INotifyPropertyChanged
    {

    }
}
