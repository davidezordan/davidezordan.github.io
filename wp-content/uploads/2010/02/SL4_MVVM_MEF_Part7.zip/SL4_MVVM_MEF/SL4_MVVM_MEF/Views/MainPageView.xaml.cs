﻿using System.Windows.Controls;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.MEFModule.Helper;

namespace SL4_MVVM_MEF.MEFModule.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    [Export(typeof(MainPageView))]
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();
        }

        [Import(ExportNames.MainPageViewModel)]
        public object DataContextImported { set { DataContext = value; } }
    }
}
