﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Silverlight.Testing;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SL4_MVVM_MEF.MEFModule.ViewModels;

namespace SL4_MVVM_MEF_UnitTests
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
        [Description("Test the creation of a ViewModel and the initialization of Design/Test Data")]
        public void TestViewModelCreation()
        {
            var vm = new MainPageViewModel();
            Assert.IsNotNull(vm);
            Assert.AreEqual(vm.dataItems.Count, 2);
        }
    }
}