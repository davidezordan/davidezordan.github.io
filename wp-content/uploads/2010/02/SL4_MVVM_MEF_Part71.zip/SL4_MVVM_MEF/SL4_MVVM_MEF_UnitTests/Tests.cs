﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SL4_MVVM_MEF.MEFModule.ViewModels;

namespace SL4_MVVM_MEF_UnitTests
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
        [Description("Test the creation of a ViewModel and the initialization of Design/Test Data")]
        public void TestViewModelCreation()
        {
            var vm = new MainPageViewModel();
            Assert.IsNotNull(vm);
            Assert.AreEqual(vm.dataItems.Count, 2);
        }
    }
}