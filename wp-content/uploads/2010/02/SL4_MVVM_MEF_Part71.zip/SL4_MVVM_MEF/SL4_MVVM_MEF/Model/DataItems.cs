﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System;

namespace SL4_MVVM_MEF.MEFModule.Model
{
    /// <summary>
    /// A sample collection of DataItems
    /// </summary>
    public class DataItems : ObservableCollection<DataItem>
    {

    }
}
