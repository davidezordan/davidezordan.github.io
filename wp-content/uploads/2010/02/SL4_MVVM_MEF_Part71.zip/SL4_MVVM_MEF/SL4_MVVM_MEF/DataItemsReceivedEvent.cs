﻿using Microsoft.Practices.Composite.Presentation.Events;
using SL4_MVVM_MEF.MEFModule.Model;

namespace SL4_MVVM_MEF.MEFModule
{
    public class DataItemsReceivedEvent : CompositePresentationEvent<DataItems>
    {

    }
}