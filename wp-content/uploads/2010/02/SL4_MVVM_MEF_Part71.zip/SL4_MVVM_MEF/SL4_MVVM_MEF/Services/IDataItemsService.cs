﻿using SL4_MVVM_MEF.MEFModule.Model;

namespace SL4_MVVM_MEF.MEFModule.Services
{
    /// <summary>
    /// Interface for the IDataItemsService
    /// </summary>
    public interface IDataItemsService
    {
        DataItems GetTestDataItems();
        void GetDataItems();
        bool isLoading { get; set; }
    }
}
