﻿using Microsoft.Practices.Composite.Events;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.MEFModule.MEFProviders
{
    public class EventAggregatorProvider
    {
        /// <summary>
        /// Export the EventAggregator
        /// </summary>
        [Export(typeof(IEventAggregator))]
        public IEventAggregator eventAggregator { get { return new EventAggregator(); } }
    }
}
