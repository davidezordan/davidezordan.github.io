﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using SL4_MVVM_MEF.MEFModule.Model;
using SL4_MVVM_MEF.MEFModule.Services;
using SL4_MVVM_MEF.MEFModule.Helper;
using Microsoft.Practices.Composite.Events;

namespace SL4_MVVM_MEF.MEFModule.ViewModels
{
    /// <summary>
    /// ViewModel class for the MainPageView
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(ExportNames.MainPageViewModel)]
    public class MainPageViewModel : ViewModelBase, IMainPageViewModel, IPartImportsSatisfiedNotification
    {
        /// <summary>
        /// Instance of the Event Aggregator
        /// </summary>
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// ImportingConstructor
        /// </summary>
        [ImportingConstructor]
        public MainPageViewModel(IEventAggregator eventAggregator, IDataItemsService dataItemsService)
        {
            _eventAggregator = eventAggregator;
            _dataItemsService = dataItemsService;
        }
        
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel() 
        {
            //Initialize the properties with test data for Design/Testing
            aViewModelProperty = "Value - Design Mode";
            this.dataItems=new DataItemsService().GetTestDataItems();
        }

        /// <summary>
        /// A sample property
        /// </summary>
        [Import(ExportNames.aViewModelPropertyTextProvider)]
        public string aViewModelProperty 
        { 
            get { return _aViewModelProperty; }
            set 
            { 
                _aViewModelProperty = value; 
                NotifyPropertyChanged("aViewModelProperty"); 
            } 
        }
        private string _aViewModelProperty;

        /// <summary>
        /// DataItems Service
        /// </summary>
        public IDataItemsService dataItemsService
        {
            get { return _dataItemsService; }
            set 
            { 
                _dataItemsService = value; 
                NotifyPropertyChanged("dataItemsService"); 
            }
        }
        private IDataItemsService _dataItemsService;

        /// <summary>
        /// A sample collection
        /// </summary>
        public DataItems dataItems 
        { 
            get { return _dataItems; }
            set 
            { 
                _dataItems = value; 
                NotifyPropertyChanged("dataItems"); 
            } 
        }
        private DataItems _dataItems;

        /// <summary>
        /// A sample Command
        /// </summary>
        [Import(typeof(ICommand))]
        public ICommand addDataItemCommand { get; set; }

        #region IPartImportsSatisfiedNotification Members

        /// <summary>
        /// Called when all the MEF imports are satistied
        /// </summary>
        public void OnImportsSatisfied()
        {
            //Initialize the dataItems
            dataItems = null;

            //Call the Service
            _dataItemsService.GetDataItems();

            //Subscribe to the "DataItemsReceivedEvent"
            _eventAggregator.GetEvent<DataItemsReceivedEvent>().Subscribe(
                dataItemsReceived =>
                {
                    dataItems = dataItemsReceived;
                }, 
                true
            );
        }

        #endregion
    }
}
