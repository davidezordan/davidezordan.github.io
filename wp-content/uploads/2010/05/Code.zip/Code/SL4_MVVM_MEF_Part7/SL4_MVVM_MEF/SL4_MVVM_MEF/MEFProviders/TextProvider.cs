﻿using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.MEFModule.MEFProviders
{
    public class TextProvider
    {
        [Export("aViewModelPropertyTextProvider")]
        public string ViewModelPropertyProvider { get { return "This is the content of a ViewModel property"; } }
    }
}
