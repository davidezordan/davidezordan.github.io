﻿using System.Windows.Controls;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.MEFModule.Helper;

namespace SL4_MVVM_MEF.MEFModule.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();

            CompositionInitializer.SatisfyImports(this);
        }

        [Import(ExportNames.MainPageViewModel)]
        public object dataContextImported { set { DataContext = value; } }
    }
}
