﻿using System;
using System.Windows.Input;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.MEFModule.ViewModels;
using SL4_MVVM_MEF.MEFModule.Model;

namespace SL4_MVVM_MEF.MEFModule.Commands
{
/// <summary>
/// A simple Command to add a new DataItem in the ViewModel collection
/// </summary>
[Export(typeof(ICommand))]
public class AddDataItemCommand : ICommand
{
    public bool CanExecute(object parameter)
    {
        return true;
    }

    public event EventHandler CanExecuteChanged;

    /// <summary>
    /// Execute the command. Add a DataItem to the collection
    /// </summary>
    public void Execute(object parameter)
    {
         if (parameter != null)
            if (parameter is MainPageViewModel) 
            {
                var dataItem = new DataItem() { Description="This is a new DataItem!" };
                ((MainPageViewModel)parameter).dataItems.Add(dataItem);
            }
    }
}
}
