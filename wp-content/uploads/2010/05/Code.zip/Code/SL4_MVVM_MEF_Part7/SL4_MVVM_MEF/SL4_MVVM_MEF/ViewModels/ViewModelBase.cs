﻿using System;
using System.ComponentModel;

namespace SL4_MVVM_MEF.MEFModule.ViewModels
{
    /// <summary>
    /// Base ViewModel class
    /// </summary>
    public class ViewModelBase : IViewModelBase
    {
        /// <summary>
        /// Event handler
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// NotifyPropertyChanged implementation
        /// </summary>
        /// <param name="PropertyName"></param>
        public void NotifyPropertyChanged(String PropertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
    }
}
