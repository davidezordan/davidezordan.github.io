﻿using SL4_MVVM_MEF.MEFModule.Model;
using System.ComponentModel.Composition;
using Microsoft.Practices.Composite.Events;
using System.Linq;

namespace SL4_MVVM_MEF.MEFModule.Services
{
    [Export(typeof(IDataItemsService))]
    public class DataItemsService : ViewModels.ViewModelBase, IDataItemsService
    {
        private readonly IEventAggregator _eventAggregator;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="eventAggregator">EventAggregator instance imported via MEF</param>
        [ImportingConstructor]
        public DataItemsService(IEventAggregator eventAggregator)
        {
            _eventAggregator = eventAggregator;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public DataItemsService()
        {

        }

        /// <summary>
        /// Get Design-time or test DataItems 
        /// </summary>
        public DataItems GetTestDataItems()
        {
           var dataItems = new DataItems
                               {
                                   new DataItem() {Description = "Sample Data Item 1 - Design Mode"},
                                   new DataItem() {Description = "Sample Data Item 2 - Design Mode"}
                               };
            return dataItems;
        }

        /// <summary>
        /// Get Run-time DataItems
        /// </summary>
        public void GetDataItems()
        {
            //Initialize the collection
            var svc = new DataItemWcfService.DataItemServiceClient();
            svc.GetDataItemsCompleted += (s1, e1) =>
            {
                if (e1.Result != null)
                {
                    var dataItems = new DataItems();
                    e1.Result.ToList().ForEach(d => dataItems.Add(new DataItem() { Description = d.Description }));

                    //Publish the DataItems
                    _eventAggregator.GetEvent<DataItemsReceivedEvent>().Publish(dataItems);

                    isLoading = false;
                }
            };
            svc.GetDataItemsAsync();
            isLoading = true;
        }

        /// <summary>
        /// Is loading property
        /// </summary>
        private bool _isLoading;
        public bool isLoading 
        { 
            get { return _isLoading; }
            set { _isLoading = value; NotifyPropertyChanged("isLoading"); } 
        }
    }
}
