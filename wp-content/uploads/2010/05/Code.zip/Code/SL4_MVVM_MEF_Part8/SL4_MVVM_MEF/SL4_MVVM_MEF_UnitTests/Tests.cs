﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SL4_MVVM_MEF.MEFModule.ViewModels;

namespace SL4_MVVM_MEF_UnitTests
{
    [TestClass]
    public class Tests
    {
        [TestMethod]
        [Description("Test the creation of a ViewModel and the initialization of Design/Test Data")]
        public void TestViewModelCreation()
        {
            TestViewVM _vm = new TestViewVM();
            Assert.IsNotNull(_vm);
            Assert.AreEqual(_vm.dataItems.Count, 2);
        }
    }
}