﻿using System;
using System.Windows.Input;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.MEFModule.Model;
using Microsoft.Practices.Composite.Events;

namespace SL4_MVVM_MEF.MEFModule.Commands
{
/// <summary>
/// A simple Command to add a new DataItem in the ViewModel collection
/// </summary>
[Export(typeof(ICommand))]
public class AddDataItemCommand : ICommand
{
    private IEventAggregator _eventAggregator;

    [ImportingConstructor]
    public AddDataItemCommand(IEventAggregator eventAggregator)
    {
        _eventAggregator = eventAggregator;
    }

    public bool CanExecute(object parameter)
    {
        return true;
    }

    public event EventHandler CanExecuteChanged;

    /// <summary>
    /// Execute the command. Add a DataItem to the collection
    /// </summary>
    public void Execute(object parameter)
    {
        if ((parameter != null) && (parameter is DataItems))
        {
            var _dataItems = (DataItems)parameter;
            _dataItems.Add(new DataItem() { Description = "This is a new DataItem!" });
            _eventAggregator.GetEvent<DataItemsReceivedEvent>().Publish(_dataItems);
        }
    }
}
}
