﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Windows.Controls;
using System.Windows.Navigation;
using SL4_MVVM_MEF;

namespace SL4_MVVM_MEF_Navigation
{
    public partial class MEFModuleContainer : Page, IPartImportsSatisfiedNotification
    {
        public MEFModuleContainer()
        {
            InitializeComponent();

            /* Use PackageCatalog
            var catalog = new PackageCatalog();
            catalog.AddPackage(Package.Current);

            Package.DownloadPackageAsync(new Uri("MEFModule.xap", UriKind.Relative),
            (sender, pkg) =>
            {
                catalog.AddPackage(pkg);
                var container = new CompositionContainer(catalog);
                //container.ComposeExportedValue(catalog);
                //CompositionHost.InitializeContainer(container);
                container.ComposeParts(this);
            });
            */

            CompositionInitializer.SatisfyImports(this);

            CatalogService.AddXap("MEFModule.xap");

        }

        [Import]
        public IDeploymentCatalogService CatalogService { get; set; }

        [ImportMany(AllowRecomposition = true)]
        public Lazy<UserControl>[] MEFModuleList { get; set; }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        #region IPartImportsSatisfiedNotification Members

        public void OnImportsSatisfied()
        {
            MEFModuleList.ToList()
                .ForEach(module=> 
                    content.Items.Add(module.Value)
                );
        }

        #endregion
    }
}