﻿using System.Windows.Controls;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.MEFModule.Helper;

namespace SL4_MVVM_MEF.MEFModule.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(UserControl))]
    public partial class TestView : UserControl
    {
        public TestView()
        {
            InitializeComponent();
        }

        [Import(ExportNames.TestViewVM)]
        public object DataContextImported { set { this.DataContext = value; } }
    }
}
