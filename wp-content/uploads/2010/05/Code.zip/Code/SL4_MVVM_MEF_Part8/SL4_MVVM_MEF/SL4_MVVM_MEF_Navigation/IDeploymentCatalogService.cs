﻿using System;
using System.ComponentModel;

namespace SL4_MVVM_MEF
{
    public interface IDeploymentCatalogService
    {
        void AddXap(string uri, Action<AsyncCompletedEventArgs> completedAction = null);
        void RemoveXap(string uri);
    }
}
