﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using SL4_MVVM_MEF.Commands;

namespace SL4_MVVM_MEF.ViewModels
{
    [Export("MainPageViewModel")]
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {
            aViewModelProperty = "This is the content of a ViewModel property";

            aSampleCommand = new AViewCommand();
        }

        /// <summary>
        /// A sample property
        /// </summary>
        public string aViewModelProperty
        {
            get { return _aViewModelProperty; }
            set { _aViewModelProperty = value; NotifyPropertyChanged("aViewModelProperty"); }
        }
        private string _aViewModelProperty;

        /// <summary>
        /// A sample command
        /// </summary>
        public ICommand aSampleCommand
        {
            get { return _aSampleCommand; }
            set { _aSampleCommand = value; NotifyPropertyChanged("aSampleCommand"); }
        }
        private ICommand _aSampleCommand;
    }
}
