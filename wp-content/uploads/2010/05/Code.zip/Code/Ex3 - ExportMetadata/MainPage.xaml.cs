﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;
using System.ComponentModel.Composition;

namespace Ex3___ExportMetadata
{
    public partial class MainPage : UserControl, IPartImportsSatisfiedNotification
    {
        public MainPage()
        {
            InitializeComponent();
            CompositionInitializer.SatisfyImports(this);
        }

        //Multiple Exports detected: use ImportMany
        [ImportMany("SimpleText")]
        public IEnumerable<Lazy<string,IMetadataContent>> textList { get; set; }

        //Used to retrieve the value of the Metadata Exported by MEF
        public interface IMetadataContent
        {
            int Index { get; }
        }

        #region IPartImportsSatisfiedNotification Members

        public void OnImportsSatisfied()
        {
            lstMEFImportedItems.ItemsSource = textList;
        }

        #endregion
    }
}
