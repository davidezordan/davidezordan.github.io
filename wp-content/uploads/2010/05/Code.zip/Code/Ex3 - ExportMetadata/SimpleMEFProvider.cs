﻿using System.ComponentModel.Composition;

namespace Ex3___ExportMetadata
{
    public class SimpleMEFProvider
    {
        [Export("SimpleText")]
        [ExportMetadata("Index",0)]
        public string aSimpleTextProvider { get { return "This is a simple Text MEF Imported"; } }

        [Export("SimpleText")]
        [ExportMetadata("Index",1)]
        public string anotherSimpleTextProvider { get { return "This is another simple Text MEF Imported"; } }
    }
}
