﻿using System;
using System.ComponentModel;

namespace SL4_MVVM_MEF.ViewModels
{
    /// <summary>
    /// Base ViewModel class
    /// </summary>
    public class ViewModelBase : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}
