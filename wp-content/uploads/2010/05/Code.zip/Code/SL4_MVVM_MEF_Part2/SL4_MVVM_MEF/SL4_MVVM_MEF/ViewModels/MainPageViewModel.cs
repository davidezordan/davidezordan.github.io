﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;
using SL4_MVVM_MEF.Attributes;

namespace SL4_MVVM_MEF.ViewModels
{
    [ExportMainPageVMAttribute]
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {

        }

        /// <summary>
        /// A sample property
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public string aViewModelProperty
        {
            get { return _aViewModelProperty; }
            set { _aViewModelProperty = value; NotifyPropertyChanged("aViewModelProperty"); }
        }
        private string _aViewModelProperty;

        /// <summary>
        /// A sample command
        /// </summary>
        [Import(typeof(ICommand))]
        public ICommand aSampleCommand
        {
            get { return _aSampleCommand; }
            set { _aSampleCommand = value; NotifyPropertyChanged("aSampleCommand"); }
        }
        private ICommand _aSampleCommand;
    }
}
