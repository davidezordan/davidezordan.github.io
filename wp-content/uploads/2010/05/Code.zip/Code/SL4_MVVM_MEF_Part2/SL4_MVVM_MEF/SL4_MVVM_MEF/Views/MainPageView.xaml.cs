﻿using System.Windows.Controls;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.Attributes;

namespace SL4_MVVM_MEF.Views
{
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();

            CompositionInitializer.SatisfyImports(this);
            this.DataContext = mainPageViewModel;
        }

        [ImportMainPageVMAttribute]
        public object mainPageViewModel { get; set; }
    }
}
