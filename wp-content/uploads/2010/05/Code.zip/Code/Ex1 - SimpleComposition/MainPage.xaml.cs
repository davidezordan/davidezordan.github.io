﻿using System.ComponentModel;
using System.Windows.Controls;
using System.ComponentModel.Composition;

namespace Ex1___SimpleComposition
{
    public partial class MainPage : UserControl, INotifyPropertyChanged
    {
        public MainPage()
        {
            InitializeComponent();

            DataContext = this;
        }

        [Import("SimpleText")]
        public string textProperty
        {
            get { return _textProperty;}
            set { _textProperty = value; NotifyPropertyChanged("textProperty"); }
        }
        private string _textProperty;

        /// <summary>
        /// Call the CompositionInitializer
        /// </summary>
        private void Button_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            CompositionInitializer.SatisfyImports(this);
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }

        #endregion
    }
}
