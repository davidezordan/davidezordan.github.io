﻿using System.ComponentModel.Composition;

namespace Ex1___SimpleComposition
{
    public class SimpleMefProvider
    {
        [Export("SimpleText")]
        public string aSimpleTextProvider { get { return "This is a simple Text MEF Imported"; } }
    }
}
