﻿using System.Collections.ObjectModel;

namespace SL4_MVVM_MEF.Model
{
    /// <summary>
    /// A sample collection of DataItems
    /// </summary>
    public class DataItems : ObservableCollection<DataItem>
    {

    }
}
