﻿using System.ComponentModel.Composition;
using System.Windows.Controls;
using SL4_MVVM_MEF.Attributes;

namespace SL4_MVVM_MEF.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();

            CompositionInitializer.SatisfyImports(this);
        }

        [ImportMainPageVM]
        public object ViewModel
        {
            set { DataContext = value; }
        }
    }
}
