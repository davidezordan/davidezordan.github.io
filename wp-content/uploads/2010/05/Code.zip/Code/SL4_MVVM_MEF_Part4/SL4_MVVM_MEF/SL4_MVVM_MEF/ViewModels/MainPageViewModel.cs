﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using SL4_MVVM_MEF.Attributes;
using SL4_MVVM_MEF.Model;

namespace SL4_MVVM_MEF.ViewModels
{
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportMainPageVMAttribute]
    public class MainPageViewModel : ViewModelBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel()
        {
            
        }

        /// <summary>
        /// A sample property
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public string aViewModelProperty { get { return _aViewModelProperty; }
            set { _aViewModelProperty = value; NotifyPropertyChanged("aViewModelProperty"); }
        }
        private string _aViewModelProperty;

        /// <summary>
        /// A sample collection
        /// </summary>
        [Import(typeof(DataItems))]
        public DataItems dataItems { get { return _dataItems; }
            set { _dataItems = value; NotifyPropertyChanged("dataItems"); }
        }
        private DataItems _dataItems;

        /// <summary>
        /// A Part creator for the sample command
        /// </summary>
        [Import(typeof(ICommand))]
        public ICommand addDataItemCommand { get { return _addDataItemCommand; }
            set { _addDataItemCommand = value; NotifyPropertyChanged("addDataItemCommand"); }
        }
        private ICommand _addDataItemCommand;
    }
}
