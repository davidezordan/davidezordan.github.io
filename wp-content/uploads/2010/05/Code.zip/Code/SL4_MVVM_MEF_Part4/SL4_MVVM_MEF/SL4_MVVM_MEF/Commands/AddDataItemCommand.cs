﻿using System;
using System.Windows.Input;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;
using SL4_MVVM_MEF.Model;

namespace SL4_MVVM_MEF.Commands
{
    /// <summary>
    /// A simple Command to add a new DataItem in the ViewModel collection
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(ICommand))]
    public class AddDataItemCommand : ICommand
    {
        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (parameter != null)
                if (parameter is MainPageViewModel) 
                {
                    var dataItem = DataItemCreator.CreateExport().Value;
                    dataItem.Description = (string)"This is a new DataItem";
                    ((MainPageViewModel)parameter).dataItems.Add(dataItem);
                }
        }

        [Import(typeof(DataItem))]
        public ExportFactory<DataItem> DataItemCreator { get; set; }
    }
}
