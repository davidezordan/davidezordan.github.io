﻿using System.ComponentModel.Composition;
using System.Windows.Input;

namespace SL4_MVVM_MEF.Model
{
    /// <summary>
    /// A sample collection of DataItems
    /// </summary>
    [Export(typeof(DataItems))]
    public class SampleDataItems : DataItems
    {
        public SampleDataItems()
        {
            //Initialize the collection
            this.Add(new DataItem() { Description = "Item 1" });
            this.Add(new DataItem() { Description = "Item 2" });
        }

        [Import(typeof(DataItem))]
        public ExportFactory<DataItem> DataItemCreator { get; set; }
    }
}
