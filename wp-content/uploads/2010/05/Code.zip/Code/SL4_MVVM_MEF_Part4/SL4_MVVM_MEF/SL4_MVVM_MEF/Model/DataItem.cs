﻿using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Model
{
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(DataItem))]
    public class DataItem
    {
        public string Description { get; set; }
    }
}
