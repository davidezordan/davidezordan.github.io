﻿using System.ComponentModel.Composition;

namespace Ex1___SimpleComposition
{
    public class SimpleMEFProvider
    {
        [Export("SimpleText")]
        public string aSimpleTextProvider { get { return "This is a simple Text MEF Imported"; } }

        [Export("SimpleText")]
        public string anotherSimpleTextProvider { get { return "This is another simple Text MEF Imported"; } }
    }
}
