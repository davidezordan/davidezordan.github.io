﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Controls;
using System.ComponentModel.Composition;

namespace Ex1___SimpleComposition
{
    public partial class MainPage : UserControl, IPartImportsSatisfiedNotification
    {
        public MainPage()
        {
            InitializeComponent();

            CompositionInitializer.SatisfyImports(this);
        }

        //Multiple Exports detected: use ImportMany
        [ImportMany("SimpleText", AllowRecomposition=true)]
        public Lazy<string>[] textProperty 
        {
            set {
                    _textList = new List<string>();
                    value.ToList().ForEach(s => _textList.Add(s.Value));
            } 
        }
        private List<string> _textList;

        
        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void NotifyPropertyChanged(string name)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(name));
        }

        #endregion

        #region IPartImportsSatisfiedNotification Members

        public void OnImportsSatisfied()
        {
            lstTest.ItemsSource = _textList;
        }

        #endregion
    }
}
