﻿using System.ComponentModel;
using System;
using SL4_MVVM_MEF.MEFModule.Model;
using System.ComponentModel.Composition;
using System.Windows.Input;
using SL4_MVVM_MEF.MEFModule.Services;

namespace SL4_MVVM_MEF.MEFModule.ViewModels
{
    /// <summary>
    /// TestView ViewModel interface
    /// </summary>
    public interface ITestViewVM : IViewModelBase
    {
        string aViewModelProperty { get; set; }
        DataItems dataItems { get; set; }
        ICommand addDataItemCommand { get; set; }
        IDataItemsService dataItemsService { get; set; }
    }
}
