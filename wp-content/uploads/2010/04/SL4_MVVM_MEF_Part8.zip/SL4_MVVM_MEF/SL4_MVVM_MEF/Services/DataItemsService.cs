﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using SL4_MVVM_MEF.MEFModule.Model;
using System.ComponentModel.Composition;
using Microsoft.Practices.Composite.Events;
using System.Linq;

namespace SL4_MVVM_MEF.MEFModule.Services
{
    [Export(typeof(IDataItemsService))]
    public class DataItemsService : ViewModels.ViewModelBase, IDataItemsService
    {
        private IEventAggregator _eventAggregator;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="eventAggregator">EventAggregator instance imported via MEF</param>
        [ImportingConstructor]
        public DataItemsService(IEventAggregator eventAggregator)
        {
            _eventAggregator = eventAggregator;
        }

        /// <summary>
        /// Default constructor
        /// </summary>
        public DataItemsService()
        {

        }

        /// <summary>
        /// Get Design-time or test DataItems 
        /// </summary>
        public DataItems GetTestDataItems()
        {
           var dataItems = new DataItems();
           dataItems.Add(new DataItem() { Description = "Sample Data Item 1 - Design Mode" });
           dataItems.Add(new DataItem() { Description = "Sample Data Item 2 - Design Mode" });
           return dataItems;
        }

        /// <summary>
        /// Get Run-time DataItems
        /// </summary>
        public void GetDataItems()
        {
            //Initialize the collection

           var dataItems = new DataItems();
           dataItems.Add(new DataItem() { Description = "Sample Data Item 1" });
           dataItems.Add(new DataItem() { Description = "Sample Data Item 2" });

           //Publish the DataItems
           _eventAggregator.GetEvent<DataItemsReceivedEvent>().Publish(dataItems);

           isLoading = false;
        }

        /// <summary>
        /// Is loading property
        /// </summary>
        private bool _isLoading;
        public bool isLoading 
        { 
            get { return _isLoading; }
            set { _isLoading = value; NotifyPropertyChanged("isLoading"); } 
        }
    }
}
