﻿using System.Collections.Generic;
using System.ServiceModel;
using System.Threading;

namespace SL4DuplexService.Web
{
    public class OrderService : IDuplexService
    {
        IDuplexClient client;
        string orderName;
        int orderQuantity;

        public void Order(string name, int quantity)
        {
            // Grab client callback channel.
            client = OperationContext.Current.GetCallbackChannel<IDuplexClient>();
            orderName = name;
            orderQuantity = quantity;

            // Pretend service is processing and will call client back in 5 seconds.
            using (Timer timer = new Timer(new TimerCallback(CallClient), null, 5000, 5000))
            {
                Thread.Sleep(11000);

            }
        }

        bool processed = false;

        private void CallClient(object o)
        {
            Order order = new Order();
            order.Payload = new List<string>();

            // Process order.
            if (processed)
            {
                // Pretend service is fulfilling the order.
                while (orderQuantity-- > 0)
                {
                    order.Payload.Add(orderName + orderQuantity);
                }

                order.Status = OrderStatus.Completed;

            }
            else
            {
                // Pretend service is processing payment.
                order.Status = OrderStatus.Processing;
                processed = true;
            }

            // Call client back
            client.Receive(order);

        }

    }

    public class Order
    {
        public OrderStatus Status { get; set; }
        public List<string> Payload { get; set; }
    }

    public enum OrderStatus
    {
        Processing,
        Completed
    }

}

