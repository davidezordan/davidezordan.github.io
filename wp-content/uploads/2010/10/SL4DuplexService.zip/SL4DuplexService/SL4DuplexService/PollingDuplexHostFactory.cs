﻿using System;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;

namespace SL4DuplexService.Web
{
    public class PollingDuplexServiceHostFactory : ServiceHostFactoryBase
    {
        public override ServiceHostBase CreateServiceHost(string constructorString,
            Uri[] baseAddresses)
        {
            return new PollingDuplexSimplexServiceHost(baseAddresses);
        }
    }

    class PollingDuplexSimplexServiceHost : ServiceHost
    {
        public PollingDuplexSimplexServiceHost(params System.Uri[] addresses)
        {
            base.InitializeDescription(typeof(OrderService), new UriSchemeKeyedCollection(addresses));
            base.Description.Behaviors.Add(new ServiceMetadataBehavior());
        }

        protected override void InitializeRuntime()
        {
            // Add an endpoint for the given service contract.
            this.AddServiceEndpoint(
                typeof(IDuplexService),
                new CustomBinding(
                    new PollingDuplexBindingElement(),
                    new BinaryMessageEncodingBindingElement(),
                    new HttpTransportBindingElement()),
                    "");

            // Add a metadata endpoint.
            this.AddServiceEndpoint(
                typeof(IMetadataExchange),
                MetadataExchangeBindings.CreateMexHttpBinding(),
                "mex");

            base.InitializeRuntime();
        }
    }
}


