﻿// Auto generated configuration elements
