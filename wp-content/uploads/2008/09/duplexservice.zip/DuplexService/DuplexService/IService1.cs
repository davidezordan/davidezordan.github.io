﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization;
using System;

namespace DuplexService
{
    [ServiceContract(Namespace = "Silverlight",
                     CallbackContract = typeof(IDuplexClient))]
    public interface IDuplexService
    {
        [OperationContract(IsOneWay = true)]
        void Order(Message receivedMessage);

        [OperationContract]
        MyObject DummyMethod();
    }

    [ServiceContract]
    public interface IDuplexClient
    {
        [OperationContract(IsOneWay = true)]
        void Receive(Message returnMessage);
    }
}
