﻿using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Threading;
using System.Runtime.Serialization;
using System;

namespace DuplexService
{
    [DataContract]
    public class MyObject
    {
        [OperationContract]
        public String GetValue()
        {
            return "Hello";
        }
    }

    public class OrderService : IDuplexService
    {
        public MyObject DummyMethod()
        { 
            return null;
        }

        IDuplexClient client;

        public void Order(Message receivedMessage)
        {
            // Grab the client callback channel.
            client = OperationContext.Current.GetCallbackChannel<IDuplexClient>();

            // Pretend that the service is processing and will call the client back in 5 seconds.
            using (Timer timer = new Timer(new TimerCallback(CallClient),
                receivedMessage.GetBody<string>(), 5000, 5000))
            {
                Thread.Sleep(11000);

            }
        }

        bool processed = false;

        private void CallClient(object order)
        {
            string text;

            // Process the order.
            if (processed)
            {
                text = (string)order + " order complete";
            }
            else
            {
                text = "Processing " + (string)order + " order";
                processed = true;
            }

            // Construct the message to return to the client.
            Message returnMessage = Message.CreateMessage(MessageVersion.Soap11,
                "Silverlight/IDuplexService/Receive", text);

            // Call the client back.
            client.Receive(returnMessage);

        }
    }
}
