package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1.miaInterfacciaHolder
<li> <b>Source File</b> esempio1/miaInterfacciaHolder.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
final public class miaInterfacciaHolder implements org.omg.CORBA.portable.Streamable {
  public esempio1.miaInterfaccia value;
  public miaInterfacciaHolder() {
  }
  public miaInterfacciaHolder(esempio1.miaInterfaccia value) {
    this.value = value;
  }
  public void _read(org.omg.CORBA.portable.InputStream input) {
    value = esempio1.miaInterfacciaHelper.read(input);
  }
  public void _write(org.omg.CORBA.portable.OutputStream output) {
    esempio1.miaInterfacciaHelper.write(output, value);
  }
  public org.omg.CORBA.TypeCode _type() {
    return esempio1.miaInterfacciaHelper.type();
  }
}
