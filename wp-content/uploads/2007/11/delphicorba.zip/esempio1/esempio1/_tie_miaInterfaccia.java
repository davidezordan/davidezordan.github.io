package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1._tie_miaInterfaccia
<li> <b>Source File</b> esempio1/_tie_miaInterfaccia.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
public class _tie_miaInterfaccia extends esempio1._miaInterfacciaImplBase {
  private esempio1.miaInterfacciaOperations _delegate;
  public _tie_miaInterfaccia(esempio1.miaInterfacciaOperations delegate, java.lang.String name) {
    super(name);
    this._delegate = delegate;
  }
  public _tie_miaInterfaccia(esempio1.miaInterfacciaOperations delegate) {
    this._delegate = delegate;
  }
  public esempio1.miaInterfacciaOperations _delegate() {
    return this._delegate;
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::inizializza</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    void inizializza(
      in long valore
    );
  </pre>
  </p>
  */
  public void inizializza(
    int valore
  ) {
    this._delegate.inizializza(
      valore
    );
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::valorecorrente</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long valorecorrente();
  </pre>
  </p>
  */
  public int valorecorrente() {
    return this._delegate.valorecorrente(
    );
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::incrementa</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long incrementa();
  </pre>
  </p>
  */
  public int incrementa() {
    return this._delegate.incrementa(
    );
  }
  /**
  <p>
  Writer for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public void numero(
    int numero
  ) {
    this._delegate.numero(
      numero
    );
  }
  /**
  <p>
  Reader for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public int numero() {
    return this._delegate.numero(
    );
  }
}
