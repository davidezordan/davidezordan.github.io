package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1._example_miaInterfaccia
<li> <b>Source File</b> esempio1/_example_miaInterfaccia.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
public class _example_miaInterfaccia extends esempio1._miaInterfacciaImplBase {
  /** Construct a persistently named object. */
  public _example_miaInterfaccia(java.lang.String name) {
    super(name);
  }
  /** Construct a transient object. */
  public _example_miaInterfaccia() {
    super();
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::inizializza</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    void inizializza(
      in long valore
    );
  </pre>
  </p>
  */
  public void inizializza(
    int valore
  ) {
    // IMPLEMENT: Operation
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::valorecorrente</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long valorecorrente();
  </pre>
  </p>
  */
  public int valorecorrente() {
    // IMPLEMENT: Operation
    return 0;
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::incrementa</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long incrementa();
  </pre>
  </p>
  */
  public int incrementa() {
    // IMPLEMENT: Operation
    return 0;
  }
  /**
  <p>
  Writer for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public void numero(
    int numero
  ) {
    // IMPLEMENT: Writer for attribute
  }
  /**
  <p>
  Reader for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public int numero() {
    // IMPLEMENT: Reader for attribute
    return 0;
  }
}
