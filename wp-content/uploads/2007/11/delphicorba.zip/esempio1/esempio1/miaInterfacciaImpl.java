package esempio1;

public class miaInterfacciaImpl extends esempio1._miaInterfacciaImplBase {

  private int v;

  public miaInterfacciaImpl(java.lang.String name) {
    super(name);
  }
  public miaInterfacciaImpl() {
    super();
  }
  public void inizializza(
    int valore
  ) {
    // IMPLEMENT: Operation
    v=valore;
  }
  public int valorecorrente() {
    // IMPLEMENT: Operation
    return v;
  }
  public int incrementa() {
    // IMPLEMENT: Operation
    v++;
    return 0;
  }
  public void numero(
    int numero
  ) {
    // IMPLEMENT: Writer for attribute
    v=numero;
  }
  public int numero() {
    // IMPLEMENT: Reader for attribute
    return v;
  }
}
