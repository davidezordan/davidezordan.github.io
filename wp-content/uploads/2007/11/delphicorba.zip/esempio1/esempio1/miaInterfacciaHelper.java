package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1.miaInterfacciaHelper
<li> <b>Source File</b> esempio1/miaInterfacciaHelper.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
abstract public class miaInterfacciaHelper {
  public static esempio1.miaInterfaccia narrow(org.omg.CORBA.Object object) {
    return narrow(object, false);
  }
  private static esempio1.miaInterfaccia narrow(org.omg.CORBA.Object object, boolean is_a) {
    if(object == null) {
      return null;
    }
    if(object instanceof esempio1.miaInterfaccia) {
      return (esempio1.miaInterfaccia) object;
    }
    if(is_a || object._is_a(id())) {
      esempio1._st_miaInterfaccia result = (esempio1._st_miaInterfaccia)new esempio1._st_miaInterfaccia();
      ((org.omg.CORBA.portable.ObjectImpl) result)._set_delegate
        (((org.omg.CORBA.portable.ObjectImpl) object)._get_delegate());
      ((org.omg.CORBA.portable.ObjectImpl) result._this())._set_delegate
        (((org.omg.CORBA.portable.ObjectImpl) object)._get_delegate());
      return (esempio1.miaInterfaccia) result._this();
    }
    return null;
  }
  public static esempio1.miaInterfaccia bind(org.omg.CORBA.ORB orb) {
    return bind(orb, null, null, null);
  }
  public static esempio1.miaInterfaccia bind(org.omg.CORBA.ORB orb, java.lang.String name) {
    return bind(orb, name, null, null);
  }
  public static esempio1.miaInterfaccia bind(org.omg.CORBA.ORB orb, java.lang.String name, java.lang.String host, org.omg.CORBA.BindOptions options) {
    if (orb instanceof com.visigenic.vbroker.orb.ORB) {
      return narrow(((com.visigenic.vbroker.orb.ORB)orb).bind(id(), name, host, options), true);
    }
    else {
      throw new org.omg.CORBA.BAD_PARAM();
    }
  }
  private static org.omg.CORBA.ORB _orb() {
    return org.omg.CORBA.ORB.init();
  }
  public static esempio1.miaInterfaccia read(org.omg.CORBA.portable.InputStream _input) {
    return esempio1.miaInterfacciaHelper.narrow(_input.read_Object(), true);
  }
  public static void write(org.omg.CORBA.portable.OutputStream _output, esempio1.miaInterfaccia value) {
    _output.write_Object(value);
  }
  public static void insert(org.omg.CORBA.Any any, esempio1.miaInterfaccia value) {
    org.omg.CORBA.portable.OutputStream output = any.create_output_stream();
    write(output, value);
    any.read_value(output.create_input_stream(), type());
  }
  public static esempio1.miaInterfaccia extract(org.omg.CORBA.Any any) {
    if(!any.type().equal(type())) {
      throw new org.omg.CORBA.BAD_TYPECODE();
    }
    return read(any.create_input_stream());
  }
  private static org.omg.CORBA.TypeCode _type;
  public static org.omg.CORBA.TypeCode type() {
    if(_type == null) {
      _type = _orb().create_interface_tc(id(), "miaInterfaccia");
    }
    return _type;
  }
  public static java.lang.String id() {
    return "IDL:esempio1/miaInterfaccia:1.0";
  }
}
