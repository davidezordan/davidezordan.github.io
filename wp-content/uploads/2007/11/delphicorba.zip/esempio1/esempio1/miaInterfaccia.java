package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1.miaInterfaccia
<li> <b>Source File</b> esempio1/miaInterfaccia.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
public interface miaInterfaccia extends com.inprise.vbroker.CORBA.Object {
  /**
  <p>
  Writer for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public void numero(
    int numero
  );
  /**
  <p>
  Reader for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public int numero();
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::inizializza</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    void inizializza(
      in long valore
    );
  </pre>
  </p>
  */
  public void inizializza(
    int valore
  );
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::valorecorrente</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long valorecorrente();
  </pre>
  </p>
  */
  public int valorecorrente();
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::incrementa</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long incrementa();
  </pre>
  </p>
  */
  public int incrementa();
}
