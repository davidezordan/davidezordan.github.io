package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1._st_miaInterfaccia
<li> <b>Source File</b> esempio1/_st_miaInterfaccia.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
public class _st_miaInterfaccia extends com.inprise.vbroker.CORBA.portable.ObjectImpl implements esempio1.miaInterfaccia {
  protected esempio1.miaInterfaccia _wrapper = null;
  public esempio1.miaInterfaccia _this() {
    return this;
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:esempio1/miaInterfaccia:1.0"
  };
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::inizializza</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    void inizializza(
      in long valore
    );
  </pre>
  </p>
  */
  public void inizializza(
    int valore
  ) {
    org.omg.CORBA.portable.OutputStream _output;
    org.omg.CORBA.portable.InputStream _input;
    while(true) {
      _output = this._request("inizializza", true);
      _output.write_long(valore);
      try {
        _input = this._invoke(_output, null);
      }
      catch(org.omg.CORBA.TRANSIENT _exception) {
        continue;
      }
      break;
    }
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::valorecorrente</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long valorecorrente();
  </pre>
  </p>
  */
  public int valorecorrente() {
    org.omg.CORBA.portable.OutputStream _output;
    org.omg.CORBA.portable.InputStream _input;
    int _result;
    while(true) {
      _output = this._request("valorecorrente", true);
      try {
        _input = this._invoke(_output, null);
        _result = _input.read_long();
      }
      catch(org.omg.CORBA.TRANSIENT _exception) {
        continue;
      }
      break;
    }
    return _result;
  }
  /**
  <p>
  Operation: <b>::esempio1::miaInterfaccia::incrementa</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    long incrementa();
  </pre>
  </p>
  */
  public int incrementa() {
    org.omg.CORBA.portable.OutputStream _output;
    org.omg.CORBA.portable.InputStream _input;
    int _result;
    while(true) {
      _output = this._request("incrementa", true);
      try {
        _input = this._invoke(_output, null);
        _result = _input.read_long();
      }
      catch(org.omg.CORBA.TRANSIENT _exception) {
        continue;
      }
      break;
    }
    return _result;
  }
  /**
  <p>
  Writer for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public void numero(
    int numero
  ) {
    org.omg.CORBA.portable.OutputStream _output;
    org.omg.CORBA.portable.InputStream _input;
    while(true) {
      _output = this._request("_set_numero", true);
      _output.write_long(numero);
      try {
        _input = this._invoke(_output, null);
      }
      catch(org.omg.CORBA.TRANSIENT _exception) {
        continue;
      }
      break;
    }
  }
  /**
  <p>
  Reader for attribute: <b>::esempio1::miaInterfaccia::numero</b>.
  <pre>
    #pragma prefix "esempio1/miaInterfaccia"
    attribute long numero;
  </pre>
  </p>
  */
  public int numero() {
    org.omg.CORBA.portable.OutputStream _output;
    org.omg.CORBA.portable.InputStream _input;
    int _result;
    while(true) {
      _output = this._request("_get_numero", true);
      try {
        _input = this._invoke(_output, null);
        _result = _input.read_long();
      }
      catch(org.omg.CORBA.TRANSIENT _exception) {
        continue;
      }
      break;
    }
    return _result;
  }
}
