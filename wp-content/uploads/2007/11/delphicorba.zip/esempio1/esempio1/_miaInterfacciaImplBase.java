package esempio1;
/**
<p>
<ul>
<li> <b>Java Class</b> esempio1._miaInterfacciaImplBase
<li> <b>Source File</b> esempio1/_miaInterfacciaImplBase.java
<li> <b>IDL Source File</b> esempio1.idl
<li> <b>IDL Absolute Name</b> ::esempio1::miaInterfaccia
<li> <b>Repository Identifier</b> IDL:esempio1/miaInterfaccia:1.0
</ul>
<b>IDL definition:</b>
<pre>
    #pragma prefix "esempio1"
    interface miaInterfaccia {
      attribute long numero;
      void inizializza(
        in long valore
      );
      long valorecorrente();
      long incrementa();
    };
</pre>
</p>
*/
abstract public class _miaInterfacciaImplBase extends com.inprise.vbroker.CORBA.portable.Skeleton implements esempio1.miaInterfaccia {
  protected esempio1.miaInterfaccia _wrapper = null;
  public esempio1.miaInterfaccia _this() {
    return this;
  }
  protected _miaInterfacciaImplBase(java.lang.String name) {
    super(name);
  }
  public _miaInterfacciaImplBase() {
  }
  public java.lang.String toString() {
    try {
      return super.toString();
    } catch (org.omg.CORBA.SystemException ex) { // delegate may not be set yet
      return "Unbound instance of esempio1.miaInterfaccia";
    }
  }
  public java.lang.String[] _ids() {
    return __ids;
  }
  private static java.lang.String[] __ids = {
    "IDL:esempio1/miaInterfaccia:1.0"
  };
  public org.omg.CORBA.portable.MethodPointer[] _methods() {
    org.omg.CORBA.portable.MethodPointer[] methods = {
      new org.omg.CORBA.portable.MethodPointer("inizializza", 0, 0),
      new org.omg.CORBA.portable.MethodPointer("valorecorrente", 0, 1),
      new org.omg.CORBA.portable.MethodPointer("incrementa", 0, 2),
      new org.omg.CORBA.portable.MethodPointer("_set_numero", 0, 3),
      new org.omg.CORBA.portable.MethodPointer("_get_numero", 0, 4),
    };
    return methods;
  }
  public boolean _execute(org.omg.CORBA.portable.MethodPointer method, org.omg.CORBA.portable.InputStream input, org.omg.CORBA.portable.OutputStream output) {
    switch(method.interface_id) {
    case 0: {
      return esempio1._miaInterfacciaImplBase._execute(_this(), method.method_id, input, output); 
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
  public static boolean _execute(esempio1.miaInterfaccia _self, int _method_id, org.omg.CORBA.portable.InputStream _input, org.omg.CORBA.portable.OutputStream _output) {
    switch(_method_id) {
    case 0: {
      int valore;
      valore = _input.read_long();
      _self.inizializza(valore);
      return false;
    }
    case 1: {
      int _result = _self.valorecorrente();
      _output.write_long(_result);
      return false;
    }
    case 2: {
      int _result = _self.incrementa();
      _output.write_long(_result);
      return false;
    }
    case 3: {
      int numero;
      numero = _input.read_long();
      _self.numero(numero);
      return false;
    }
    case 4: {
      int _result = _self.numero();
      _output.write_long(_result);
      return false;
    }
    }
    throw new org.omg.CORBA.MARSHAL();
  }
}
