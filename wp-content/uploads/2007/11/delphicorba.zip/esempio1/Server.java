// Server.java

public class Server {

  public static void main(String[] args) {
    // Inizializza l'ORB.
    org.omg.CORBA.ORB orb = org.omg.CORBA.ORB.init(args,null);
    // Inizializza BOA.
    org.omg.CORBA.BOA boa =     ((com.visigenic.vbroker.orb.ORB)orb).BOA_init();
    // Crea l'oggetto miaInterfaccia.
    esempio1.miaInterfaccia i =
      new esempio1.miaInterfacciaImpl("Istanza_miaInterfaccia");
    // Esporta l'oggetto.
    boa.obj_is_ready(i);
    System.out.println(i + " in esecuzione.");
    // Attende le richieste dai client
    boa.impl_is_ready();
  }

}

