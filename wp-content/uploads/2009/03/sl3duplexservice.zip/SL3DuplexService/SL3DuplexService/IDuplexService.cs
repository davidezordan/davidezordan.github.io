﻿using System.ServiceModel;

namespace SL3DuplexService
{
    [ServiceContract(Namespace = "Silverlight", CallbackContract = typeof(IDuplexClient))]
    public interface IDuplexService
    {
        [OperationContract(IsOneWay = true)]
        void Order(string name, int quantity);
    }

    [ServiceContract]
    public interface IDuplexClient
    {
        [OperationContract(IsOneWay = true)]
        void Receive(Order order);
    }
}

