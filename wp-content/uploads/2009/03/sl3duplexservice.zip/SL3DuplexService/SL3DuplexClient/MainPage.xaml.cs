﻿using System.Windows.Controls;
using System.ServiceModel;
using System.ServiceModel.Channels;
using SL3DuplexClient.SL3DuplexService;
using System;

namespace SL3DuplexClient
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            EndpointAddress address = new EndpointAddress("http://localhost:19021/DuplexService.svc");

            CustomBinding binding = new CustomBinding(
                new PollingDuplexBindingElement(),
                new BinaryMessageEncodingBindingElement(),
                new HttpTransportBindingElement());

            DuplexServiceClient proxy = new DuplexServiceClient(binding, address);
            proxy.ReceiveReceived += new EventHandler<ReceiveReceivedEventArgs>(proxy_ReceiveReceived);
            proxy.OrderAsync("Widget", 3);
            reply.Text = "Sent order of 3 Widgets." + Environment.NewLine;

        }

        void proxy_ReceiveReceived(object sender, ReceiveReceivedEventArgs e)
        {
            if (e.Error == null)
            {
                reply.Text += "Service reports Widget order is " + e.order.Status + "." + Environment.NewLine;

                if (e.order.Status == OrderStatus.Completed)
                {
                    reply.Text += "Here is the completed order:" + Environment.NewLine;

                    foreach (string order in e.order.Payload)
                    {
                        reply.Text += order + Environment.NewLine;
                    }
                }

            }
        }

    }

}
