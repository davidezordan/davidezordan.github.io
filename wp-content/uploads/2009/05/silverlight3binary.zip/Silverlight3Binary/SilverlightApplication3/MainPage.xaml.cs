﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ServiceModel;
using System.ServiceModel.Channels;

namespace SilverlightApplication3
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            EndpointAddress address = new EndpointAddress("http://localhost:17594/Service1.svc");

            CustomBinding binding = new CustomBinding(
                new BinaryMessageEncodingBindingElement(),
                new HttpTransportBindingElement());

            ServiceReference1.Service1Client svc = new ServiceReference1.Service1Client(binding, address);
            svc.DoWorkCompleted += (s1, e1) => { if (e1.Error==null && e1.Result != null) MessageBox.Show(e1.Result); };
            svc.DoWorkAsync();
        }
    }
}
