﻿using SL4_MVVM_MEF.Attributes;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.PartCreators
{
    /// <summary>
    /// Get the ViewModel instance via the PartCreator<T>
    /// </summary>
    public class ViewModelPartCreator
    {
        public ViewModelPartCreator() { }

        [ImportMainPageVMAttribute]
        public PartCreator<object> mainPageViewModelPartCreator { get; set; }

        /// <summary>
        /// Get the imported Instance of the ViewModel
        /// </summary>
        public object GetVMInstance
        {
            get
            {
                PartInitializer.SatisfyImports(this);
                return mainPageViewModelPartCreator.CreatePart().ExportedValue;
            }
        }
    }
}
