﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;
using SL4_MVVM_MEF.Attributes;

namespace SL4_MVVM_MEF.ViewModels
{
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportMainPageVMAttribute]
    public class MainPageViewModel : ViewModelBase
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel() { }

        /// <summary>
        /// A Part Creator for the aViewModelProperty
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public PartCreator<string> aViewModelPropertyCreator { get; set; }

        /// <summary>
        /// A sample property
        /// </summary>
        private string _aViewModelProperty;
        public string aViewModelProperty
        {
            get 
            {
                if (_aViewModelProperty == null)
                {
                    _aViewModelProperty = aViewModelPropertyCreator.CreatePart().ExportedValue;
                }
                return _aViewModelProperty; 
            }
            set { _aViewModelProperty = value; NotifyPropertyChanged("aViewModelProperty"); }
        }

        /// <summary>
        /// A Part creator for the sample command
        /// </summary>
        [Import(typeof(ICommand))]
        public PartCreator<ICommand> aSampleCommandCreator { get; set; }

        /// <summary>
        /// A sample command
        /// </summary>
        public ICommand aSampleCommand
        {
            get
            {
                return aSampleCommandCreator.CreatePart().ExportedValue;
            }
        }

        /// <summary>
        /// A simple property
        /// </summary>
        private string _aSimpleProperty = "A simple property sample";
        public string aSimpleProperty { 
            get { return _aSimpleProperty; }
            set { _aSimpleProperty = value; NotifyPropertyChanged("aSimpleProperty"); } 
        }
    }
}
