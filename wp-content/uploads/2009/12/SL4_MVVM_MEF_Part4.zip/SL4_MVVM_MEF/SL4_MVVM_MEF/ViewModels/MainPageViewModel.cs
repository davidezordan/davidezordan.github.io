﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;
using SL4_MVVM_MEF.Attributes;
using SL4_MVVM_MEF.Model;

namespace SL4_MVVM_MEF.ViewModels
{
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [ExportMainPageVMAttribute]
    public class MainPageViewModel : ViewModelBase
    {
        #region Constructor
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel() { }
        #endregion

        #region Properties
        /// <summary>
        /// A sample property
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public string aViewModelProperty { get; set; }

        /// <summary>
        /// A sample collection
        /// </summary>
        [Import(typeof(DataItems))]
        public DataItems dataItems { get; set; }
        #endregion

        #region Commands
        /// <summary>
        /// A Part creator for the sample command
        /// </summary>
        [Import(typeof(ICommand))]
        public PartCreator<ICommand> addDataItemCommandCreator { get; set; }

        /// <summary>
        /// A sample command
        /// </summary>
        public ICommand addDataItemCommand
        {
            get
            {
                return addDataItemCommandCreator.CreatePart().ExportedValue;
            }
        }
        #endregion
    }
}
