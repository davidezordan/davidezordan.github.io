﻿using SL4_MVVM_MEF.Attributes;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Providers
{
    /// <summary>
    /// Get the ViewModel instance
    /// </summary>
    public class ViewModelProvider
    {
        public ViewModelProvider() { }

        [ImportMainPageVMAttribute]
        public object mainPageViewModelProvider { get; set; }

        /// <summary>
        /// Get the imported Instance of the ViewModel
        /// </summary>
        public object GetVMInstance
        {
            get
            {
                PartInitializer.SatisfyImports(this);
                return mainPageViewModelProvider;
            }
        }
    }
}
