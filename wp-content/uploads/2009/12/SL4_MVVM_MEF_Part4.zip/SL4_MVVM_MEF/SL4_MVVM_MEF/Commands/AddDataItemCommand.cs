﻿using System;
using System.Windows;
using System.Windows.Input;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;
using SL4_MVVM_MEF.Attributes;
using SL4_MVVM_MEF.Model;

namespace SL4_MVVM_MEF.Commands
{
    /// <summary>
    /// A simple Command to add a new DataItem in the ViewModel collection
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(ICommand))]
    public class AddDataItemCommand : ICommand
    {
        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (parameter != null)
                if (parameter is string) 
                {
                    DataItem dataItem = DataItemCreator.CreatePart().ExportedValue;
                    dataItem.Description = (string)parameter;
                    viewModel.dataItems.Add(dataItem);
                }
        }

        [ImportMainPageVMAttribute]
        public MainPageViewModel viewModel { get; set; }

        [Import(typeof(DataItem))]
        public PartCreator<DataItem> DataItemCreator { get; set; }
    }
}
