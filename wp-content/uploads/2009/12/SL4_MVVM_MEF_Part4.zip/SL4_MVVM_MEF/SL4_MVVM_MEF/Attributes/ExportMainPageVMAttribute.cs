﻿using System;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;

namespace SL4_MVVM_MEF.Attributes
{
    [AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
    public class ExportMainPageVMAttribute : ExportAttribute
    {
        public ExportMainPageVMAttribute(): base(typeof(ViewModelBase))
        {

        }
    }
}
