﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Interop;

namespace SL4BetaSpeechAPI
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            if (App.Current.HasElevatedPermissions)
            {
                dynamic speech = ComAutomationFactory.CreateObject("Sapi.SpVoice");
                speech.Volume = 100;
                speech.Speak(SpeechText.Text);
            }
            else MessageBox.Show("Sorry, install the application first :)");
        }
    }
}
