﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;

namespace SL4_MVVM_MEF.ViewModels
{
    [Export("MainPageViewModel")]
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {
            aViewModelProperty = "This is the content of a ViewModel property";

            aSampleCommand = new AViewCommand();
        }

        /// <summary>
        /// A sample property
        /// </summary>
        public string aViewModelProperty { get; set; }

        /// <summary>
        /// A sample command
        /// </summary>
        public ICommand aSampleCommand {get; set;}
    }
}
