﻿using System.Windows.Controls;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Views
{
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();

            PartInitializer.SatisfyImports(this);
            this.DataContext = mainPageViewModel;
        }

        [Import("MainPageViewModel")]
        public object mainPageViewModel { get; set; }
    }
}
