﻿using System;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;

namespace SL4_MVVM_MEF.Attributes
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class ImportMainPageVMAttribute : ImportAttribute
    {
        public ImportMainPageVMAttribute() : base(typeof(ViewModelBase))
        {

        }
    }
}
