﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Commands
{
    /// <summary>
    /// A simple Command in Silverlight 4 Beta
    /// </summary>
    [Export(typeof(ICommand))]
    public class AViewCommand : ICommand
    {
        public bool CanExecute(object parameter)
        {
            return true;
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (parameter != null)
                if (parameter is string) MessageBox.Show((string)parameter);
        }
    }
}
