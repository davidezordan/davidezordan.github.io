﻿using System;
using System.ComponentModel;
using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;
using SL4_MVVM_MEF.Attributes;

namespace SL4_MVVM_MEF.ViewModels
{
    [ExportMainPageVMAttribute]
    public class MainPageViewModel : ViewModelBase
    {
        public MainPageViewModel()
        {

        }

        /// <summary>
        /// A sample property
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public string aViewModelProperty { get; set; }

        /// <summary>
        /// A sample command
        /// </summary>
        [Import(typeof(ICommand))]
        public ICommand aSampleCommand {get; set;}
    }
}
