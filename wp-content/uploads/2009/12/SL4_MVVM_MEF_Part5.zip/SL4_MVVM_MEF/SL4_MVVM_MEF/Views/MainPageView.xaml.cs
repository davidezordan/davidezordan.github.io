﻿using System.Windows;
using System.Windows.Controls;
using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();
        }        
    }
}
