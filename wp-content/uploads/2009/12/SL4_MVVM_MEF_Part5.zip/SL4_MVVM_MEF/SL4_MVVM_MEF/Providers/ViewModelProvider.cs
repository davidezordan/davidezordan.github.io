﻿using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;
using System.Windows;

namespace SL4_MVVM_MEF.Providers
{
/// <summary>
/// Get the ViewModel instance
/// </summary>
public class ViewModelProvider : IViewModelProvider
{
    public ViewModelProvider() { }

    [Import(typeof(MainPageViewModel))]
    public IViewModelBase mainPageViewModelProvider { get; set; }

    /// <summary>
    /// Get the Instance of the ViewModel
    /// </summary>
    public IViewModelBase GetVMInstance
    {
        get
        {
            //Verify if Design Mode
            if ((Application.Current == null) || (Application.Current.GetType() == typeof(Application)))
            {
                return new MainPageViewModel();
            }
            else
            {
                PartInitializer.SatisfyImports(this);
                return mainPageViewModelProvider;
            } 
        }
    }
}
}
