﻿using System.ComponentModel;
using System;
using SL4_MVVM_MEF.Model;
using System.ComponentModel.Composition;
using System.Windows.Input;

namespace SL4_MVVM_MEF.ViewModels
{
    /// <summary>
    /// MainPage ViewModel interface
    /// </summary>
    public interface IMainPageViewModel : IViewModelBase
    {
        string aViewModelProperty { get; set; }
        DataItems dataItems { get; set; }
        PartCreator<ICommand> addDataItemCommandCreator { get; set; }
        ICommand addDataItemCommand { get; }
    }
}
