﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Commands;
using SL4_MVVM_MEF.Model;
using System.Linq;

namespace SL4_MVVM_MEF.ViewModels
{
[PartCreationPolicy(CreationPolicy.NonShared)]
[Export(typeof(MainPageViewModel))]
public class MainPageViewModel : ViewModelBase, IMainPageViewModel
{
    /// <summary>
    /// Default constructor
    /// </summary>
    public MainPageViewModel() 
    {
        if ((Application.Current == null) || (Application.Current.GetType()==typeof(Application)))
        {
            //Initialize the properties with test data if design mode
            aViewModelProperty = "Value - Design Mode";
            dataItems = new SampleDataItems(); dataItems.ToList().ForEach(d=>d.Description+=" - Design Mode");
        }
    
    }

    /// <summary>
    /// A sample property
    /// </summary>
    [Import("aViewModelPropertyTextProvider")]
    public string aViewModelProperty { get; set; }

    /// <summary>
    /// A sample collection
    /// </summary>
    [Import(typeof(DataItems))]
    public DataItems dataItems { get; set; }

    /// <summary>
    /// A Part creator for the addDataItemCommandCreator
    /// </summary>
    [Import(typeof(ICommand))]
    public PartCreator<ICommand> addDataItemCommandCreator { get; set; }

    private ICommand _addDataItemCommand;
    public ICommand addDataItemCommand
    {
        get { 
            if (_addDataItemCommand==null)
                _addDataItemCommand = addDataItemCommandCreator.CreatePart().ExportedValue;
            return _addDataItemCommand; 
        }
    }
}
}
