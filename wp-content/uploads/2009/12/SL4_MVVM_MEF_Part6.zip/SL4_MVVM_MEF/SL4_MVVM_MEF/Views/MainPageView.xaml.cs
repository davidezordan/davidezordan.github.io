﻿using System.Windows.Controls;

namespace SL4_MVVM_MEF.Views
{
    /// <summary>
    /// The Main Page View
    /// </summary>
    public partial class MainPageView : UserControl
    {
        public MainPageView()
        {
            InitializeComponent();
        }
    }
}
