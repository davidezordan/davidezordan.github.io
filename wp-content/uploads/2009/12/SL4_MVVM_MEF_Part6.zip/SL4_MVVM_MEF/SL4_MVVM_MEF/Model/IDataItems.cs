﻿using System.Collections.ObjectModel;
using System.ComponentModel;

namespace SL4_MVVM_MEF.Model
{
    /// <summary>
    /// A sample collection of DataItem
    /// </summary>
    public interface IDataItems : INotifyPropertyChanged
    {
        bool isLoading { get; set; }
    }
}
