﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System;

namespace SL4_MVVM_MEF.Model
{
    /// <summary>
    /// A sample collection of DataItems
    /// </summary>
    public class DataItems : ObservableCollection<DataItem>, IDataItems, INotifyPropertyChanged
    {
        private bool _isLoading;
        public bool isLoading
        {
            get
            {
                return _isLoading;
            }
            set
            {
                _isLoading = value;
                NotifyPropertyChanged("isLoading");
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// NotifyPropertyChanged implementation
        /// </summary>
        /// <param name="PropertyName"></param>
        public void NotifyPropertyChanged(String PropertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(PropertyName));
            }
        }
    }
}
