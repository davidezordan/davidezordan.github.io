﻿using System.ComponentModel.Composition;

namespace SL4_MVVM_MEF.Model
{
    /// <summary>
    /// A generic DataItem
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(DataItem))]
    public class DataItem
    {
        public string Description { get; set; }
    }
}
