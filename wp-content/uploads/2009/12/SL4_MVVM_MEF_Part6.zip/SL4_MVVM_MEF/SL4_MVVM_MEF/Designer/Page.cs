﻿using System.Windows;

namespace SL4_MVVM_MEF.Designer
{
    public class Page
    {
        /// <summary>
        /// DesignDataContext Attached Dependency Property
        /// </summary>
        public static readonly DependencyProperty DesignDataContextProperty =
            DependencyProperty.RegisterAttached("DesignDataContext", typeof(object), typeof(Page),
                new PropertyMetadata((object)null,
                    new PropertyChangedCallback(OnDesignDataContextChanged)));

        /// <summary>
        /// Gets the DesignDataContext property.   
        /// </summary>
        public static object GetDesignDataContext(DependencyObject d)
        {
            return (object)d.GetValue(DesignDataContextProperty);
        }

        /// <summary>
        /// Sets the DesignDataContext property.   
        /// </summary>
        public static void SetDesignDataContext(DependencyObject d, object value)
        {
            d.SetValue(DesignDataContextProperty, value);
        }

        /// <summary>
        /// Handles the DesignDataContext property changes   
        /// </summary>
        private static void OnDesignDataContextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            FrameworkElement element = (FrameworkElement)d;

            //Get the ViewModel instance only in design mode
            if ((Application.Current == null) || (Application.Current.GetType() == typeof(Application)))
               element.DataContext = e.NewValue;
        }
    }
}
