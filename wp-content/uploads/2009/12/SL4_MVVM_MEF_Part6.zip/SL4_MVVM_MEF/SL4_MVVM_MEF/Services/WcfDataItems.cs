﻿using System.ComponentModel.Composition;
using System.Linq;
using SL4_MVVM_MEF.Model;

namespace SL4_MVVM_MEF.Services
{
    /// <summary>
    /// A sample collection of DataItems from WCF
    /// </summary>
    [Export(typeof(WcfDataItems))]
    public class WcfDataItems : DataItems
    {
        public WcfDataItems()
        {
            //Initialize the collection
            DataItemWcfService.DataItemServiceClient svc = new DataItemWcfService.DataItemServiceClient();
            svc.GetDataItemsCompleted += (s1, e1) =>
            {
                if (e1.Result != null)
                    e1.Result.ToList().ForEach(d =>
                        {
                            //Retrieve a new DataItem using PartCreator<T>
                            DataItem di = DataItemCreator.CreatePart().ExportedValue;
                            di.Description = d.Description;
                            this.Add(di);
                        });
                isLoading = false;
            };
            svc.GetDataItemsAsync();
            isLoading = true;
        }

        [Import(typeof(DataItem))]
        public PartCreator<DataItem> DataItemCreator { get; set; }
    }
}
