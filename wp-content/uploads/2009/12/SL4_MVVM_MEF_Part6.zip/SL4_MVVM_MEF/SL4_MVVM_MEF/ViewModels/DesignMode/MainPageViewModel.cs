﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using System.Windows;
using SL4_MVVM_MEF.Model;
using System.Linq;

namespace SL4_MVVM_MEF.ViewModels.DesignMode
{
    /// <summary>
    /// ViewModel for the "MainPageView" used in design-mode
    /// </summary>
    public class MainPageViewModel : ViewModelBase, IMainPageViewModel
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel() 
        {
            //Initialize the properties with test data if design mode
            aViewModelProperty = "Value - Design Mode";
            
            //Initialize the "dataItems" property
            dataItems = new DataItems();
            dataItems.Add(new DataItem() { Description = "Sample Data Item 1 - Design Mode" });
            dataItems.Add(new DataItem() { Description = "Sample Data Item 2 - Design Mode" });
        }

        /// <summary>
        /// A sample property
        /// </summary>
        public string aViewModelProperty { get; set; }

        /// <summary>
        /// A sample collection
        /// </summary>
        public DataItems dataItems { get; set; }

        /// <summary>
        /// addDataItemCommand
        /// </summary>
        public ICommand addDataItemCommand { get; set; }
    }
}
