﻿using System.ComponentModel.Composition;
using System.Windows.Input;
using SL4_MVVM_MEF.Model;
using SL4_MVVM_MEF.Services;

namespace SL4_MVVM_MEF.ViewModels
{
    /// <summary>
    /// ViewModel class for the MainPageView
    /// </summary>
    [PartCreationPolicy(CreationPolicy.NonShared)]
    [Export(typeof(MainPageViewModel))]
    public class MainPageViewModel : ViewModelBase, IMainPageViewModel
    {
        /// <summary>
        /// Default constructor
        /// </summary>
        public MainPageViewModel() 
        {

        }

        /// <summary>
        /// A sample property
        /// </summary>
        [Import("aViewModelPropertyTextProvider")]
        public string aViewModelProperty { get; set; }

        /// <summary>
        /// A sample collection
        /// </summary>
        [Import(typeof(WcfDataItems))]
        public DataItems dataItems { get; set; }

        /// <summary>
        /// A Part creator for the addDataItemCommandCreator
        /// </summary>
        [Import(typeof(ICommand))]
        public PartCreator<ICommand> addDataItemCommandCreator { get; set; }

        private ICommand _addDataItemCommand;
        public ICommand addDataItemCommand
        {
            get { 
                if (_addDataItemCommand==null)
                    _addDataItemCommand = addDataItemCommandCreator.CreatePart().ExportedValue;
                return _addDataItemCommand; 
            }
        }
    }
}
