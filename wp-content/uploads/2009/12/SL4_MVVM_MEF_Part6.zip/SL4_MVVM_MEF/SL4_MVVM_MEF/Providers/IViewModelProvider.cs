﻿using SL4_MVVM_MEF.ViewModels;

namespace SL4_MVVM_MEF.Providers
{
    /// <summary>
    /// Interface for the ViewModelProvider
    /// </summary>
    public interface IViewModelProvider
    {
        object GetViewModel { get; }
    }
}
