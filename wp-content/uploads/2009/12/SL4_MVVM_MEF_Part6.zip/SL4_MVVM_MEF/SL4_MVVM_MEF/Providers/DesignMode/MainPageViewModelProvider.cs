﻿
namespace SL4_MVVM_MEF.Providers.DesignMode
{
/// <summary>
/// Get the ViewModel instance
/// </summary>
/// 
public class MainPageViewModelProvider : IViewModelProvider
{
    public MainPageViewModelProvider() { }

    /// <summary>
    /// Get the Instance of the ViewModel
    /// </summary>
    public object GetViewModel
    {
        get
        {
            return new ViewModels.DesignMode.MainPageViewModel();
        }
    }
}
}
