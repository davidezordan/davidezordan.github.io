﻿using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;
using System.Windows;

namespace SL4_MVVM_MEF.Providers
{
    /// <summary>
    /// Get the ViewModel instance using MEF
    /// </summary>
    /// 
    public class MainPageViewModelMEFProvider : IViewModelProvider
    {
        public MainPageViewModelMEFProvider() { }

        [Import(typeof(MainPageViewModel))]
        public IViewModelBase ViewModel { get; set; }

        /// <summary>
        /// Get the Instance of the ViewModel
        /// </summary>
        public object GetViewModel
        {
            get
            {
               PartInitializer.SatisfyImports(this);
               return ViewModel;
            }
        }
}
}
