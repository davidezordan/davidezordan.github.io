﻿using System;
using System.Windows.Input;
using System.ComponentModel.Composition;
using SL4_MVVM_MEF.ViewModels;
using SL4_MVVM_MEF.Model;
using System.ComponentModel;
using System.Windows;

namespace SL4_MVVM_MEF.Commands
{
/// <summary>
/// A simple Command to add a new DataItem in the ViewModel collection
/// </summary>
[PartCreationPolicy(CreationPolicy.NonShared)]
[Export(typeof(ICommand))]
public class AddDataItemCommand : ICommand
{
    public bool CanExecute(object parameter)
    {
        return true;
    }

    public event EventHandler CanExecuteChanged;

    /// <summary>
    /// Execute the command. Add a DataItem to the collection
    /// </summary>
    /// <param name="parameter"></param>
    public void Execute(object parameter)
    {
         if (parameter != null)
            if (parameter is string) 
            {
                var dataItem = DataItemCreator.CreatePart().ExportedValue;
                dataItem.Description = (string)parameter;
                viewModel.dataItems.Add(dataItem);
                viewModel.NotifyPropertyChanged("GetViewModel.dataItems");
            }
    }

    [Import(typeof(MainPageViewModel))]
    public MainPageViewModel viewModel { get; set; }

    [Import(typeof(DataItem))]
    public PartCreator<DataItem> DataItemCreator { get; set; }
}
}
