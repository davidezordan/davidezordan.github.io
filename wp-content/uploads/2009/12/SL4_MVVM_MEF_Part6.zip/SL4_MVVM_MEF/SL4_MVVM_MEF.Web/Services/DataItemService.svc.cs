﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;

namespace SL4_MVVM_MEF.Web.Services
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class DataItemService : IDataItemService
    {
        [OperationContract]
        public List<DataItemFromService> GetDataItems()
        {
            // Add your operation implementation here
            return new List<DataItemFromService>() 
            { 
                new DataItemFromService() {Description="DataItem from service 1"},
                new DataItemFromService() {Description="DataItem from service 2"},
                new DataItemFromService() {Description="DataItem from service 3"}
            };
        }

        // Add more operations here and mark them with [OperationContract]
    }

    interface IDataItemService
    {
        List<DataItemFromService> GetDataItems();
    }

    public class DataItemFromService
    {
        public string Description { get; set; }
    }
}
