﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace phpTest
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnCall_Click(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadStringCompleted += (s1, e1) => txtResult.Text = e1.Result;
            wc.DownloadStringAsync(new Uri("http://www.davidezordan.net/samples/php/phpInfo.php", UriKind.Absolute));
        }

        private void btnCallPar_Click(object sender, RoutedEventArgs e)
        {
            WebClient wc = new WebClient();
            wc.DownloadStringCompleted += (s1, e1) => txtResultPar.Text = e1.Result;
            wc.DownloadStringAsync(new Uri("http://www.davidezordan.net/samples/php/phpGetExample.php?name="+txtParameter.Text, UriKind.Absolute));

        }
    }
}
