﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Xml;
using System.IO;

namespace SilverlightHeaders.Web
{
    /// <summary>
    /// Summary description for WebService1
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    // [System.Web.Script.Services.ScriptService]
    public class WebService1 : System.Web.Services.WebService
    {

        [WebMethod]
        public string Hello(String name)
        {
            string Username = String.Empty;
            string Password = String.Empty;

            try
            {
                if (HttpContext.Current.Request.ServerVariables["HTTP_SOAPACTION"] != null)
                {
                    // Load the body of the HTTP message
                    // into an XML document.
                    Stream HttpStream = HttpContext.Current.Request.InputStream;
                    HttpStream.Position = 0;
                    XmlDocument dom = new XmlDocument();
                    dom.Load(HttpStream);
                    // Bind to the Authentication header.
                    Username =
                        dom.GetElementsByTagName("Username").Item(0).InnerText;
                    Password =
                        dom.GetElementsByTagName("Password").Item(0).InnerText;
                }
            }
            catch { }
            
            return "Hello " +name+", your Username is: " + Username + ", your password is: "+ Password;
        }
    }
}
