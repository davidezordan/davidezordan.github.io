﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;
using System.Text;

namespace SilverlightHeaders.Web
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Service
    {
        [OperationContract]
        public string SayHello(string name)
        {
            string ipAddress = OperationContext.Current.IncomingMessageHeaders.GetHeader<string>("IpAddress", "");
            return "Hello " + name + ", from IP " + ipAddress + ".";
        }
    }
}
