﻿using System.ServiceModel;
using System.Windows.Controls;
using Microsoft.Silverlight.Samples;
using SilverlightHeaders.ServiceReference;
using SilverlightHeaders.ServiceReference1;
using System.Windows;

namespace SilverlightHeaders
{
    public partial class Page : UserControl
    {
        ServiceClient proxy;
        WebService1SoapClient proxyAsmx;

        public Page(string ipAddress)
        {
            InitializeComponent();

            proxy = new ServiceClient(new BasicHttpMessageInspectorBinding(new SilverlightAuthMessageInspector("Davide","myPassword")),
                new EndpointAddress("http://localhost:44816/Service.svc"));
            proxy.SayHelloCompleted += (s1,e1)=>
                {
                    if (e1.Error == null)
                    {
                        result.Text = e1.Result;
                    }               
                };

            proxyAsmx = new WebService1SoapClient(new BasicHttpMessageInspectorBinding(new SilverlightAuthMessageInspector("Davide", "myPassword")),
                         new EndpointAddress("http://localhost:44816/WebService1.asmx"));
            proxyAsmx.HelloCompleted += (s1, e1) =>
            {
                if (e1.Error == null)
                {
                    result.Text = e1.Result;
                }
            };
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //proxy.SayHelloAsync(name.Text);
            proxyAsmx.HelloAsync(name.Text);
        }
    }
}
