﻿using System;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using Microsoft.Silverlight.Samples;

namespace SilverlightHeaders
{
    public class SilverlightAuthMessageInspector : IClientMessageInspector
    {
        private string username, password;

        public SilverlightAuthMessageInspector(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            request.Headers.Add(MessageHeader.CreateHeader("Username", "", this.username));
            request.Headers.Add(MessageHeader.CreateHeader("Password", "", this.password));
            
            return null;
        }

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {
        }
    }

}