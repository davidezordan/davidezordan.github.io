﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SilverlightWebBrowser
{
    public partial class Page : UserControl
    {
        public Page()
        {
            InitializeComponent();

            System.Windows.Browser.HtmlElement myFrame = System.Windows.Browser.HtmlPage.Document.GetElementById("ifHtmlContent");
            if (myFrame != null)
            {
                myFrame.SetStyleAttribute("width", "1024");
                myFrame.SetStyleAttribute("height", "768");
                myFrame.SetAttribute("src", txtURI.Text);
                myFrame.SetStyleAttribute("left", "0");
                myFrame.SetStyleAttribute("top", "50");
                myFrame.SetStyleAttribute("visibility", "visible");            
            }
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            this.Button_Click(sender, e);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            System.Windows.Browser.HtmlElement myFrame = System.Windows.Browser.HtmlPage.Document.GetElementById("ifHtmlContent");
            if (myFrame != null) myFrame.SetAttribute("src", txtURI.Text);
        }

        private void txtURI_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
                this.Button_Click(sender, e);
        }
    }
}
